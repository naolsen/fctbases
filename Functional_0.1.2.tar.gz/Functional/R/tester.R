

# Buffer script
if (F) {
  fs1 <- createObject('bmwarp_init_fourier_basis', c(-0.1, 4.5), 2)
 fb1 <- createODE(fs1, fs1, fs1, 3)

 y <- matrix (, 7, 100)
  y[1,] <- 1:100/100
 for (i in 2:4) y[i,] <- exp(0:99/100 + rnorm(100)* 0.003)

  k0 <- abs(rnorm(105)) * 0.01

  # maker_simpel(attr(fb1, 'address'), y, matrix(rnorm(105)), exp(c(10, -10)), matrix(1:6), abs(rnorm(105)))

  for (i in 5:7) y[i,] <- exp(0:99/100 + rnorm(100)* 0.03)

  fs1 <- createObject('bmwarp_init_fourier_basis', c(-0.1, 4.5), 1)
  fb1 <- createODE(fs1, fs1, fs1, 2)

  y <- matrix (, 5, 100)
  y[1,] <- 1:100/100
  for (i in 2:3) y[i,] <- exp(0:99/100 + rnorm(100)* 0.003)

  k0 <- abs(rnorm(105)) * 0.01
  k1 <- rep(0.01, 30)
  k1[29:30] <- 1

  res <- maker_simpel(attr(fb1, 'address'), y, matrix(rep(1,30)), exp(c(-2, -10, -12)), matrix(c(1,1 , 0.01,0.01)), abs(rnorm(30)))

  for (i in 5:7) y[i,] <- exp(0:99/100 + rnorm(100)* 0.03)

  y <- cbind(y, y)

  res <- maker_simpel(attr(fb1, 'address'), y, matrix(rep(1,30)), exp(c(-2, -10, -12)),
                      matrix(c(1,1 , 0.01,0.01), 4, 2), abs(rnorm(30)))

  curve_solver(attr(fb1, 'address'), res$parameter_estimates,  matrix(c(1,1 , 0.01,0.01), 4, 2), 0:100/100)


  wf <- create.warp.function(type = "piecewise linear", knots = 1:5)


  plot(eval.warp(wf, seq(1, 5, 0.03), 1:5 + rnorm(5)* 0.4), type = "l")

  od2 <- createODE(fs1, fs1, fs1, 2, wf)

  set_warp_params(attr(od2, 'address'), matrix(runif(50), 5, 10))
  }
