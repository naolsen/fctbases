


functional_environment <- new.env(parent = emptyenv())

