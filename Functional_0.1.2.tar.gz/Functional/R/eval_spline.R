




# Warning: Use with care! Should only be used 
initObject <- function(type = "...", ...) {
  
}

eval_spline <- function() 2+2
